#include <iostream>
#include "FullTimeEmployee.h"
#include "PartTimeEmployee.h"

using namespace std;

int main()
{
    FullTimeEmployee fullEmp(60000);

    PartTimeEmployee partEmp(40, 500);


    cout << "Full Time Employee Salary: "


        << fullEmp.calculateSalary() << endl;


    cout << "Part Time Employee Salary: "

        << partEmp.calculateSalary() << endl;

    return 0;
}