#pragma once

class Employee
{
public:
    virtual double calculateSalary() = 0;  
};