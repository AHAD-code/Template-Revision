#include "OnlineCourse.h"
#include "OfflineCourse.h"

int main()
{
    OnlineCourse online(8, 5);
    OfflineCourse offline(4, 6);

    online.duration();
    offline.duration();

    return 0;
}